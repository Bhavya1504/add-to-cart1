const fruits = ['apple', 'oranges', ' ', 'mango', ' ', 'lemon'];

const transformedArray = fruits.map((value) => {
  if (value === ' ') {
    return 'empty string';
  } else {
    return value;
  }
});

console.log(transformedArray);
