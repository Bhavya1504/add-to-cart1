
const http = require('http');

const express = require('express');

const appexpress = express();

appexpress.use((req, res, next) => {
    console.log('In the middleware!');
    next(); // Allows the request to continue to the next middleware in line
});

appexpress.use((req, res, next) => {
    console.log('In another middleware!');
    res.send('<h1>Hello from Express!</h1>');
});

const server = http.createServer(appexpress);

server.listen(3000);
